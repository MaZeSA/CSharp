export interface IRegister {
    firstName: string,
    lastName: string,
    email: string,
    photo: string,
    phone: string,
    password: string,
    confirmPassword: string,
}
