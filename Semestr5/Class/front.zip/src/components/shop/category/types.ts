export interface ICategoryItem{
    id: number,
    name: string,
    image: string
}