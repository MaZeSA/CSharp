﻿namespace WebBackend.Models
{
    public class ExternalLoginDTO
    {
        public string Provider { get; set; }
        public string Token { get; set; }
    }
}
